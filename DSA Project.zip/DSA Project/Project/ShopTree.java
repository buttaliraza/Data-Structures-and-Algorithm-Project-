package Project;
import java.io.IOException;
import java.util.*;
class Item {
    int price;
    String name;

    Item(String name, int price) {
        this.price = price;
        this.name = name;
    }
}

class Node {
    Item it;
    Node left;
    Node right;

    Node(String name, int price) {
        it = new Item(name, price);
        left = right = null;
    }
}

public class ShopTree {

     Node root;

    
    void printTree(Node node, String prefix, boolean isLeft) {
        if (node != null) {
   
            System.out.println(prefix + (isLeft ? "├── " : "└── ") + node.it.name + " ($" + node.it.price + ")");

   
            printTree(node.left, prefix + (isLeft ? "│   " : "    "), true);
            printTree(node.right, prefix + (isLeft ? "│   " : "    "), false);

        }
    }

    
    public Item findItem(Node node, String name) {

        if (node == null)
            return null; 
        if (node.it.name.equalsIgnoreCase(name))
            return node.it;

        
        Item leftResult = findItem(node.left, name);
        if (leftResult != null)
            return leftResult; 

        return findItem(node.right, name);
    }

    public static void main(String args[]) {
        try {
            String os = System.getProperty("os.name").toLowerCase();
            ProcessBuilder processBuilder;

            if (os.contains("win")) {
                processBuilder = new ProcessBuilder("cmd", "/c", "cls"); // Windows
            } else {
                processBuilder = new ProcessBuilder("clear");
            }
            processBuilder.inheritIO().start().waitFor(); 
        } catch (IOException | InterruptedException e) {
            e.printStackTrace(); 
        }
        ShopTree store = new ShopTree();

        store.root = new Node("Pen", 2);

        store.root.left = new Node("Pencil", 1);
        store.root.right = new Node("Pointer", 3);

        store.root.left.left = new Node("Marker", 2);
        store.root.left.right = new Node("Book", 4);

        store.root.right.left = new Node("Copy", 2);
        store.root.right.right = new Node("Scale", 1);

        // Print the tree
        System.out.println("\n       Stationary Shop:\n");
        store.printTree(store.root, "", false);
        new Cart(store);
    }
}

class Cart {

    Cart(ShopTree store) {
        Scanner input = new Scanner(System.in);
        Stack<Item> cartStk = new Stack<>();
        String items[] = new String[4];
        Stack<Integer> quantity=new Stack<>();
        System.out.println("\nSelect four items you want:");
        String array[]=new String[4];
        
        for (int i = 0; i <= 3; i++) {
            boolean validInput = false;
            while (!validInput) {
                System.out.print("Enter Name of the item, " + (i + 1) + ": ");
               items[i] = input.nextLine();
               array[i]=items[i];
                Item item = store.findItem(store.root, items[i]);
                if (item != null) {
                    cartStk.push(item);
                    System.out.println("Enter Quantity of this item: ");
                    quantity.push(input.nextInt());
                    input.nextLine();
                    validInput = true;
                } else {
                    System.out.println("Invalid entry. Item not found, please try again.");
                    new Cart(store);
                }
            }
            
        }
        
        System.out.println("\nPress 1 to See total bill\nPress any other number to make Changes in Items: ");
        Scanner a = new Scanner(System.in);
        int f =a.nextInt();
        if(f==1){
            Checkout(cartStk,quantity);

        }
        else{       
            new ShopTree().main(items);
        }
    }
    
    void Checkout(Stack<Item> stk, Stack<Integer> q) {
        System.out.println("\nCheckout Summary:");
        System.out.println("------------------------");
    
        int totalPrice = 0;
    

        Stack<Item> reversedItems = new Stack<>();
        Stack<Integer> reversedQuantities = new Stack<>();
        while (!stk.isEmpty()) {
            reversedItems.push(stk.pop());
            reversedQuantities.push(q.pop());
        }
    

        while (!reversedItems.isEmpty()) {
            Item item = reversedItems.pop();
            int quantity = reversedQuantities.pop();
            
            int itemTotal = item.price * quantity;
    
            System.out.println(item.name+ " x " +quantity +" | " + itemTotal+"$");
    
            totalPrice += itemTotal;
        }
            System.out.println("------------------------");
        System.out.println("Total Price: $" + totalPrice);
        System.out.println("\n\nPress Enter to go to the Library: ");
        Scanner sc = new Scanner (System.in);
        sc.nextLine();
        new library().main(null);
    }
    
        
}

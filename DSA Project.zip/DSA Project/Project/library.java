package Project;

import java.util.*;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

class Book {
    String name;
    String author;

    public Book(String name, String author) {
        this.name = name;
        this.author = author;
    }
    public void printBookDetails(int i) {
        System.out.println(i+ ". Book Name: '" + this.name);
    }
    public void printBookDetails() {
        System.out.print("Book Name: '" + this.name +"\n");
    }

    public void displayDateInfo() {
        // Get the current system date (issue date)
        LocalDate issueDate = LocalDate.now();

        // Calculate the due date (14 days after the issue date)
        LocalDate dueDate = issueDate.plusDays(14);

        // Format the dates in a readable format
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        System.out.print("Issue Date: " + issueDate.format(formatter));
        System.out.println("  Due Date: " + dueDate.format(formatter));
        System.out.println();
    }

}

public class library {

    public static void main(String[] args) {
        Queue<Book> Q = new LinkedList<>();
        Book[] books = {
                new Book("C++", "Robert C. Martin"),
                new Book("History", "Joshua Bloch"),
                new Book("Novel", "Andrew Hunt"),
                new Book("Physics", "Robert"),
               
        };
        System.out.println("\n\n            Welcome to the Library!\n\n     AVAILABLE BOOKS\n");

        for (int i = 0; i < books.length; i++) {
            books[i].printBookDetails(i + 1);
        }
        int b = 0;
        System.out.println(
                "------------------------------------------------------------------------------------------------\n\n      Enter book Number to Borrow it (Mximum 4 books for 14 days)\n ");
        Scanner in = new Scanner(System.in);
        int i = 0;
        int[] selected=new int[5];
        while (true) {
            System.out.print("\nEnter book number, " + (i+1) + " : ");
            b = in.nextInt();
            selected[i]=b;
            boolean t=true;
            for(int j =0;j<i;j++){
            if(selected[j]==b)
            {
                System.out.println("The book is Already Selected! Try Again!");
                t=false;
            }}
            if(t==false){
                continue;
            }
            
            boolean check = find(b);
            if (check == true) {
                Q.add(books[i]);
                i++;

            } else {
                System.out.println("Wrong Entery. Try Again!");
                continue;
            }
            if (i == 4) {
                System.out.print("\n\nPress 1 to Confirm \nand any other number to make changes: ");
                int c = in.nextInt();
                if (c == 1)
                    break;
                else {
                    i = 0;
                    b = 0;
                    continue;
                }
            }
        }
        try {
            String os = System.getProperty("os.name").toLowerCase();
            ProcessBuilder processBuilder;

            if (os.contains("win")) {
                processBuilder = new ProcessBuilder("cmd", "/c", "cls"); // Windows
            } else {
                processBuilder = new ProcessBuilder("clear");
            }
            processBuilder.inheritIO().start().waitFor(); 
        } catch (IOException | InterruptedException e) {
            e.printStackTrace(); 
        }
        System.out.println("Books with Names and IssueDate(today) and DueDate(after 14 days)\n\n");
        for(int a=1;a<=4;a++){
            Book book = Q.poll();
            System.out.print(a+":");
            book.printBookDetails();
            book.displayDateInfo();
        }
        System.out.print("\n         Press Enter to GO TO THE\n          ICE CREAM SHOP  ");
        in.nextLine();
        in.nextLine();
        System.out.println("\nGoing...............");
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        new Ice().main(args);
    }

    static boolean find(int n) {
        if (n > 10 || n < 1) {
            return false;
        } else
            return true;
    }
}
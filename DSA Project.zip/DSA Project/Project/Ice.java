package Project;

import java.util.Scanner;
import java.io.IOException;

class IceCream {
   String name;
   int price;

   IceCream(String n, int p) {
      name = n;
      price = p;
   }
}

public class Ice {
   public static void main(String[] args) {
      try {
         String os = System.getProperty("os.name").toLowerCase();
         ProcessBuilder processBuilder;

         if (os.contains("win")) {
            processBuilder = new ProcessBuilder("cmd", "/c", "cls"); // Windows
         } else {
            processBuilder = new ProcessBuilder("clear");
         }
         processBuilder.inheritIO().start().waitFor();
      } catch (IOException | InterruptedException e) {
         e.printStackTrace();
      }

      System.out.println("\n       Welcome to the Ice Cream Shop\n");
      System.out.println("Available flavours:");
      IceCream[] menu = new IceCream[4];
      menu[0] = new IceCream("Chocolate", 5);
      menu[1] = new IceCream("Strawberry", 3);
      menu[2] = new IceCream("Vanilla", 1);
      menu[3] = new IceCream("Mango", 2);

      for (int i = 0; i < 4; i++) {
         System.out.println((i + 1) + ". " + menu[i].name + " (" + menu[i].price + "$)");
      }

      System.out.println("\nChoose up to 3 different ice cream flavors:\n");
      Scanner sc = new Scanner(System.in);
      String[] chosenFlavors = new String[3];
      int[] quantities = new int[3];
      int flavorCount = 0;
      int n=0;

      while (flavorCount < 3) {
         System.out.print("Enter "+(++n)+ " flavor name: ");
         String flavor = sc.nextLine();
         boolean found = false;
         for (IceCream ic : menu){
            if (ic.name.equalsIgnoreCase(flavor)) {
               found = true;
               System.out.print("Enter quantity: ");
               int quantity = sc.nextInt();
               sc.nextLine(); 
               System.out.println();
               
               if (quantity > 0) {
                  chosenFlavors[flavorCount] = ic.name;
                  quantities[flavorCount] = quantity;
                  flavorCount++;
               } else {
                  System.out.println("Quantity must be greater than zero. Try again.");
               }
               break;
            }
         }
         
         if (!found) {
            n--;
            System.out.println("Invalid flavor. Please choose from the menu.");
         }
      }
      System.out.print("Enter 1 to see the bill\nor any other number to choose flavours again: ");
      Scanner s=new Scanner(System.in);
      int c = s.nextInt();
      if(c==1){
      }
      else{
         main(args);
      }


      System.out.println("\n       Order Summary");
      System.out.println("---------------------------------");
      int totalCost = 0;

      for (int i = 0; i < flavorCount; i++) {
         for (IceCream ic : menu) {
            if (ic.name.equalsIgnoreCase(chosenFlavors[i])) {
               int cost = ic.price * quantities[i];
               totalCost += cost;
               System.out.printf("%-15s x %d = %d$\n", chosenFlavors[i], quantities[i], cost);
            }
         }
      }

      System.out.println("---------------------------------");
      System.out.println("Total Cost:      " + totalCost + "$");
      System.out.println("\nThank you for visiting the Ice Cream Shop!");
      System.out.println("\n\nPress Enter:");
      sc.nextLine();
   }
}

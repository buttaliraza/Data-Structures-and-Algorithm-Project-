
package Project;
import java.io.IOException;
import java.util.*;

public class graph {
    static class Edge {
        int destination;
        int weight;

        Edge(int destination, int weight) {
            this.destination = destination;
            this.weight = weight;
        }
    }
    

  

    private static void addEdge(List<List<Edge>> graph, int source, int destination, int weight) {
        graph.get(source).add(new Edge(destination, weight));
    }

    private static void printGraphDiagram() {
        System.out.println("\n| Let's begin the journey! |\n");
        System.out.println("Here is a graphical representation of the places and distances:\n");
    
        System.out.println("        <------Friend 1 House (F1)");
        System.out.println("        |     /\\                 \\");
        System.out.println("       3|    4/                   \\2 ");
        System.out.println("        |    /                     \\ ");
        System.out.println("       \\/   /                      \\/");
        System.out.println(" ----->House (H)<-------7-------Friend 2 House (F2)");
        System.out.println(" |      \\                               \\");
        System.out.println(" |6      \\3                              \\ 11");
        System.out.println(" |        \\                               \\   ");
        System.out.println(" |        \\/                              \\/");
        System.out.println(" <----Ice Cream Shop (I)----- 3 --------->Stationary Shop (S)");
        System.out.println("          /\\                            /");
        System.out.println("           \\1                         2/");
        System.out.println("            \\                         / ");
        System.out.println("             \\                       \\/");
        System.out.println("              <----------------- Library (L)");
    }
    
    public static void findShortestPath(List<List<Edge>> graph, String sourceNode, String destinationNode) {
        // Node names for clarity
        String[] nodeNames = {"House", "Friend 1 House", "Friend 2 House", "Stationary Shop", "Library", "Ice Cream Shop"};
        
        // Map node names to index
        Map<String, Integer> nodeMap = new HashMap<>();
        for (int i = 0; i < nodeNames.length; i++) {
            nodeMap.put(nodeNames[i], i);
        }

        // Convert node names to indices
        int source = nodeMap.get(sourceNode);
        int destination = nodeMap.get(destinationNode);

        PriorityQueue<int[]> pq = new PriorityQueue<>(Comparator.comparingInt(a -> a[0]));
        int[] distances = new int[nodeNames.length];
        int[] predecessors = new int[nodeNames.length];
        Arrays.fill(distances, Integer.MAX_VALUE); 
        Arrays.fill(predecessors, -1); 
        distances[source] = 0;
        pq.offer(new int[]{0, source});

        while (!pq.isEmpty()) {
            int[] current = pq.poll();
            int currentDistance = current[0];
            int currentNode = current[1];

            
            if (currentDistance > distances[currentNode]) continue;

            
            for (Edge edge : graph.get(currentNode)) {
                int neighbor = edge.destination;
                int newDist = currentDistance + edge.weight;

            
                if (newDist < distances[neighbor]) {
                    distances[neighbor] = newDist;
                    predecessors[neighbor] = currentNode;
                    pq.offer(new int[]{newDist, neighbor});
                }
            }
        }
        
        printPath(predecessors, source, destination, distances[destination], nodeNames);
    }

    
    private static void printPath(int[] predecessors, int source, int destination, int totalDistance, String[] nodeNames) {
        List<Integer> path = new ArrayList<>();
        for (int at = destination; at != -1; at = predecessors[at]) {
            path.add(at);
        }
        Collections.reverse(path);

    
        System.out.print("Path: ");
        for (int i = 0; i < path.size(); i++) {
            System.out.print(nodeNames[path.get(i)]);
            if (i < path.size() - 1) {
                System.out.print(" -> ");
            }
        }
        System.out.println();
        System.out.println("So, the shortest path from " + nodeNames[source] + " to " + nodeNames[destination] + " is " + totalDistance + "km.\n");
    }
    public static void main(String[] args) {
        // Number of nodes
        try {
            String os = System.getProperty("os.name").toLowerCase();
            ProcessBuilder processBuilder;

            if (os.contains("win")) {
                processBuilder = new ProcessBuilder("cmd", "/c", "cls"); // Windows
            } else {
                processBuilder = new ProcessBuilder("clear");
            }
            processBuilder.inheritIO().start().waitFor(); 
        } catch (IOException | InterruptedException e) {
            e.printStackTrace(); 
        }
        int numberOfNodes = 6;

        // Create an adjacency list
        List<List<Edge>> graph = new ArrayList<>();
        for (int i = 0; i < numberOfNodes; i++) {
            graph.add(new ArrayList<>());
        }

        
        addEdge(graph, 0, 1, 4);
        addEdge(graph, 1, 0, 3);
        addEdge(graph, 1, 2, 2);
        addEdge(graph, 2, 0, 7);
        addEdge(graph, 2, 3, 11);
        addEdge(graph, 3, 4, 2); 
        addEdge(graph, 4, 5, 1); 
        addEdge(graph, 5, 3, 3); 
        addEdge(graph, 0, 5, 3); 
        addEdge(graph, 5, 0, 6); 

        printGraphDiagram();
        System.out.println("\nPress Enter to Caculate the Shortest Path between House to Stationary Shop......");
        Scanner sc = new Scanner(System.in);
        sc.nextLine();
        try {
            String os = System.getProperty("os.name").toLowerCase();
            ProcessBuilder processBuilder;

            if (os.contains("win")) {
                processBuilder = new ProcessBuilder("cmd", "/c", "cls"); // Windows
            } else {
                processBuilder = new ProcessBuilder("clear");
            }
            processBuilder.inheritIO().start().waitFor(); 
        } catch (IOException | InterruptedException e) {
            e.printStackTrace(); 
        }
        findShortestPath(graph,"House","Stationary Shop");
  
        System.out.println("\n  But we want to pick our 2 friends!\nWe are currently at our House! \nPress Enter to Calculate the distance from House to Friend 1 House!");
        sc.nextLine();
        findShortestPath(graph,"House","Friend 1 House");
        enter();
        System.out.println("So We are taking this path! \n\n");
        
        try {
            Thread.sleep(6000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        try {
            String os = System.getProperty("os.name").toLowerCase();
            ProcessBuilder processBuilder;

            if (os.contains("win")) {
                processBuilder = new ProcessBuilder("cmd", "/c", "cls"); // Windows
            } else {
                processBuilder = new ProcessBuilder("clear");
            }
            processBuilder.inheritIO().start().waitFor(); 
        } catch (IOException | InterruptedException e) {
            e.printStackTrace(); 
        }
        System.out.println(" Now we are arrived at 1st friend house and picked him up!\n  Press Enter to see the shortest distance to 2nd friend house!");
        sc.nextLine();
        findShortestPath(graph,"Friend 1 House","Friend 2 House");
        enter();
        System.out.println("We are taking this path!\n\n");
        
        try {
            Thread.sleep(9000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        try {
            String os = System.getProperty("os.name").toLowerCase();
            ProcessBuilder processBuilder;

            if (os.contains("win")) {
                processBuilder = new ProcessBuilder("cmd", "/c", "cls"); // Windows
            } else {
                processBuilder = new ProcessBuilder("clear");
            }
            processBuilder.inheritIO().start().waitFor(); 
        } catch (IOException | InterruptedException e) {
            e.printStackTrace(); 
        }
        System.out.println(" Now we are arrived at 2nd friend house and picked him up!");
        System.out.println("\n\n        Press Enter to go to the Stationary!");
        sc.nextLine();
        time();
        new ShopTree().main(args);
        System.out.println("\n\nNow we going back! \nFirst We have to drop our friends!");
        enter();
        findShortestPath(graph,"Ice Cream Shop","Friend 1 House");
        enter();
        System.out.println("We are taking this Shortest path!!");
        try {
            Thread.sleep(6000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        try {
            String os = System.getProperty("os.name").toLowerCase();
            ProcessBuilder processBuilder;

            if (os.contains("win")) {
                processBuilder = new ProcessBuilder("cmd", "/c", "cls"); // Windows
            } else {
                processBuilder = new ProcessBuilder("clear");
            }
            processBuilder.inheritIO().start().waitFor(); 
        } catch (IOException | InterruptedException e) {
            e.printStackTrace(); 
        }
        System.out.println("We have dropped one friend!\nPress Enter to see the next Destination point!");
        sc.nextLine();
        findShortestPath(graph,"Friend 1 House","Friend 2 House");
        enter();
        try {
            Thread.sleep(6000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        try {
            String os = System.getProperty("os.name").toLowerCase();
            ProcessBuilder processBuilder;

            if (os.contains("win")) {
                processBuilder = new ProcessBuilder("cmd", "/c", "cls"); // Windows
            } else {
                processBuilder = new ProcessBuilder("clear");
            }
            processBuilder.inheritIO().start().waitFor(); 
        } catch (IOException | InterruptedException e) {
            e.printStackTrace(); 
        }

        System.out.println("We are Arrived at 2nd friend house Now we are going to our house!!");
        enter();
        findShortestPath(graph,"Friend 2 House","House");
        System.out.println("Our last destination journey has began!!! Press Enter to go Back to House!!");
        sc.nextLine();        
        time();
        System.out.println("\nGood Bye! Thanks for using our Service!\n");
    }
    static void enter(){
        System.out.print("Press Enter");
        Scanner sc = new Scanner(System.in);
        sc.nextLine();
    }
    static void time(){
        System.out.println("\nGoing...............");
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}